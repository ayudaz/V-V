package simpleGame.core;

/**
 * The directions that can be taken by a moving Pawn.
 * @author Erwan Bousse
 *
 */
public enum Direction {
    Up,Down,Left,Right;
}